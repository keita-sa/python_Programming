from lesson_package.tools import utils

def sing():
    return '##hsuhdsfghassing'

def cry():
    return utils.say_twice('hahgskfjsliejfs')