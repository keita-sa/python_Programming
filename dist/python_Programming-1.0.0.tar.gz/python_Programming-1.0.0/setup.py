from setuptools import setup

setup(
    name='python_Programming',
    version='1.0.0',
    packages=['lesson_package', 'lesson_package.talk', 'lesson_package.tools'],
    url='',
    license='Free',
    author='keitasakurai',
    author_email='',
    description='Sample package'
)
